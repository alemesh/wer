<?php
/**
 * Intact functions file
 *
 * @package intact
 * by KeyDesign
 */

 require_once( get_template_directory() . '/core/init.php');

 // -------------------------------------
 // Edit below this line
 // -------------------------------------