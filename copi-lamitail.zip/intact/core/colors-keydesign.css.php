.tt_button:hover .iconita,
.tt_button.second-style .iconita,
#single-page #comments input[type="submit"]:hover,
.tt_button.tt_secondary_button,
.tt_button.tt_secondary_button .iconita,
.es-accordion .es-time,
.wpb-js-composer .vc_tta-container .vc_tta-color-white.vc_tta-style-modern .vc_tta-tab.vc_active a,
.CountdownContent,
.team-member.design-two:hover .team-socials .fa:hover,
.team-member.design-two .team-socials .fa:hover,
.vc_toggle_title:hover h4,
.pricing-table .tt_button,
.kd-photobox:hover .phb-content h4,
.pricing-table.active .tt_button:hover,
.vc_grid-item-mini .vc_gitem-zone .vc_btn3.vc_btn3-style-custom,
.woocommerce .star-rating span,
.navbar-default.navbar-shrink .nav li.active a,
.es-accordion .es-heading h4 a:hover,
.keydesign-cart ul.product_list_widget .cart-item:hover,
.woocommerce .keydesign-cart ul.product_list_widget .cart-item:hover,
.key-reviews:hover .rw-author-details p,
#customizer .options a:hover i,
.woocommerce .price_slider_wrapper .price_slider_amount .button,
#customizer .options a:hover,
#single-page input[type="submit"]:hover,
#posts-content .post input[type="submit"]:hover,
.active .pricing-option .fa,
.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
#comments .reply a:hover,
.meta-content .tags a:hover,
.navigation.pagination .next,
.woocommerce-cart  #single-page table.cart .product-name a:hover,
.navigation.pagination .prev,
.navbar-default .nav li a:hover,
#posts-content .entry-meta a:hover,
#posts-content .post .blog-single-title:hover,
.woocommerce span.onsale,
.product_meta a:hover,
.tags a:hover, .tagcloud a:hover,
.tt_button.second-style,
.large-counter .kd_counter_units,
.lower-footer .pull-right a:hover,
.key-reviews:hover .rw-author-details h4,
.woocommerce-review-link:hover,
.navbar.navbar-default a:hover,
.rw_rating .rw-title,
.section .wpcf7-mail-sent-ok,
.upper-footer .modal-menu-item,
.video-socials a:hover .fa,
.kd_pie_chart .pc-link a:hover,
.navbar-default.navbar-shrink .modal-menu-item:hover,
.navbar-default.navbar-shrink .nav li a:hover,
.navbar-default.navbar-shrink .nav li a:focus,
.vc_grid-item-mini .vc_gitem_row .vc_gitem-col h4:hover,
.navbar-default.navbar-shrink .nav li a:hover,
.navbar-default.navbar-shrink .nav li a:focus,
.fa,
.wpcf7 .wpcf7-submit:hover,
.contact .wpcf7-response-output,
.video-bg .secondary-button:hover,
#headerbg li a.active,
#headerbg li a.active:hover,
.footer-nav a:hover ,
.wpb_wrapper .menu a:hover ,
.text-danger,
.blog_widget ul li a:before,
.pricing .fa,
.searchform #searchsubmit:hover,
code,
#single-page .single-page-content ul li:before,
.blog_widget ul li a:hover,
.features-tabs .tab.active h5,
.subscribe-form header .wpcf7-submit,
#posts-content .page-content ul li:before,
.chart-content .nc-icon-outline,
.chart,
.row .vc_custom_heading a:hover,
.features-tabs .tab a:hover,
.secondary-button-inverse,
.primary-button.button-inverse:hover,
.primary-button,
a,
.page-404 .section-heading,
.navbar-default .navbar-nav > .active > a,
.pss-link a:hover,
.woocommerce-cart #single-page .cart_totals table td,
.kd_number_string,
.featured_content_parent .active-elem h4,
.contact-map-container .toggle-map:hover .fa,
.contact-map-container .toggle-map:hover,
.tt_button:hover,
.nc-icon-outline,
.woocommerce ul.products li.product h3:hover,
.wpb_text_column ol>li:before,
.wpb_text_column ul>li:before,
.key-icon-box .ib-link a:hover,
.kd-photobox .phb-btncontainer a:hover
{
	color: #31d093;
	color: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

.parallax.with-overlay:after,
.tt_button.tt_secondary_button:hover,
.modal-menu-item:hover,
.pricing-table .tt_button:hover,
.modal-content-inner .wpcf7-not-valid-tip,
.wpb-js-composer .vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li.vc_active a,
.tt_button.second-style:hover,
.pricing-table.active .tt_button,
#customizer .screenshot a,
.heading-separator,
.section .wpcf7-not-valid-tip,
.port-prev.tt_button:hover,
.port-next.tt_button:hover,
.row .vc_toggle_default .vc_toggle_icon,
.row .vc_toggle_default .vc_toggle_icon::after,
.row .vc_toggle_default .vc_toggle_icon::before,
.woocommerce ul.products li.product .added_to_cart,
.woocommerce #respond input#submit,
.woocommerce a.button,
.woocommerce input.button:hover,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.upper-footer .modal-menu-item:hover,
.kd-process-steps .pss-step-number span,
.contact-map-container .toggle-map,
.kd-photobox .phb-content .phb-btncontainer a,
.portfolio-item .portfolio-content,
.keydesign-cart .badge,
.wpcf7 .wpcf7-submit,
.tt_button,
.owl-controls .owl-page span,
.woocommerce a.remove:hover,
.team-content-hover,
.pricing .secondary-button.secondary-button-inverse:hover,
.with-overlay .parallax-overlay,
.secondary-button.secondary-button-inverse:hover,
.secondary-button,
.primary-button.button-inverse,
#posts-content .post input[type="submit"],
.btn-xl,
.with-overlay,
.vc_grid-item-mini .vc_gitem-zone .vc_btn3.vc_btn3-style-custom:hover,
.woocommerce .price_slider_wrapper .ui-slider-horizontal .ui-slider-range,
.separator,
.keydesign-cart .buttons .btn:hover,
.woocommerce .keydesign-cart .buttons .btn:hover,
.woocommerce ul.products li.product .button:hover,
#posts-content #comments input[type="submit"]:hover,
#single-page #comments input[type="submit"]:hover,
.contact-map-container .toggle-map:hover,
.wpcf7 .wpcf7-submit:hover,
.woocommerce button.button:hover,
.testimonials.slider .owl-controls span,
.navigation.pagination .next:hover,
.spinner:before,
.navigation.pagination .prev:hover
{
background: #31d093;
background: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}


.slider-scroll-down a {
background-color: #31d093;
background-color: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

::selection {
background-color: #31d093;
background: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

::-moz-selection {
background-color: #31d093;
background: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

#single-page #comments input[type="submit"]:hover,
#posts-content #comments input[type="submit"]:hover,
.navigation.pagination .next,
.navigation.pagination .prev,
.port-prev.tt_button,
.port-next.tt_button,
.upper-footer .modal-menu-item,
.wpcf7 .wpcf7-submit:hover,
.tt_button,
#commentform #submit,
.navigation.pagination .next, .navigation.pagination .prev,
.modal-menu-item:focus, .modal-menu-item,
.woocommerce ul.products li.product .button:hover,
.woocommerce .price_slider_wrapper .ui-slider .ui-slider-handle,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.pricing.active,
.vc_grid-item-mini .vc_gitem-zone .vc_btn3.vc_btn3-style-custom,
.primary-button.button-inverse:hover,
.primary-button.button-inverse,
.keydesign-cart .buttons .btn, .woocommerce .keydesign-cart .buttons .btn,
.wpcf7 .wpcf7-submit,
.woocommerce button.button,
.woocommerce input.button,
.owl-controls .owl-page.active span,
.owl-controls .owl-page:hover span {
	border: 2px solid #31d093;
    border: 2px solid <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

.features-tabs .tab a.active .triangle  {
	border-right: 10px solid #31d093;
    border-right: 10px solid <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}


.blockquote-reverse,
blockquote,
.testimonials.slider .owl-controls .owl-page.active span,
.tags a:hover, .tagcloud a:hover,
.contact-map-container .toggle-map:hover,
.navigation.pagination .next:hover, .navigation.pagination .prev:hover,
.contact .wpcf7-response-output,
.video-bg .secondary-button,
.image-bg .secondary-button,
.contact .wpcf7-form-control-wrap textarea.wpcf7-form-control:focus,
.contact .wpcf7-form-control-wrap input.wpcf7-form-control:focus,
.team-member-down:hover .triangle,
.team-member:hover .triangle,
.secondary-button-inverse  {
	border-color: #31d093;
    border-color: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

#main-menu .navbar-nav .menu-item-has-children .dropdown-menu,
.navbar-nav .menu-item-has-children .dropdown-menu {
	border-top-color: <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}


.wpb-js-composer .vc_tta-container  .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab:before {
    border-right: 9px solid <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}

.wpb-js-composer .vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li:before {
    border-top: 9px solid <?php echo esc_attr($redux_ThemeTek['tek-main-color']); ?>;
}


h1,h2,h3,h4,h5,h6,
.kd-calltoaction .tt_button.tt_secondary_button,
.kd_progress_bar .kd_progb_head .kd-progb-title h4,
.kd-photobox .phb-btncontainer a,
.key-icon-box .ib-link a,
.wpb-js-composer .vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li a,
 .es-accordion .es-heading h4 a,
.wpb-js-composer .vc_tta-color-white.vc_tta-style-modern .vc_tta-tab>a:hover,
#comments .reply a,
#comments .fn,
#comments .fn a,
.blog_widget ul li a,
.portfolio-block h4,
.rw-author-details h4,
.testimonials.slider .author,
.testimonials.slider .tt-content h6,
.vc_grid-item-mini .vc_gitem_row .vc_gitem-col h4,
.navbar-default.navbar-shrink .nav li a,
.team-content h5,
.key-icon-box .service-heading,
#wp-calendar caption,
.post a:hover,
.kd_pie_chart .kd_pc_title,
.kd_pie_chart .pc-link a,
.testimonials .tt-content h4,
.kd-photobox .phb-content h4,
.kd-process-steps .pss-text-area h4,
.widget-title,
.kd-promobox .prb-content h4,
.kd_counter_units,
.large-counter .kd_counter_text,
.bp-content h4,
.reply-title,
.product_meta,
.blog-header .section-heading,
.testimonial-cards .tcards-title,
.testimonial-cards .tcards_header .tcards-name,
.woocommerce-result-count,
.pss-link a,
.navigation.pagination .next, .navigation.pagination .prev,
.modal-menu-item:focus, .modal-menu-item,
.play-video .fa-play,
.navbar-default .nav li a,
#commentform #submit,
.logged-in .navbar-nav a, .navbar-nav .menu-item a,
.woocommerce table.shop_attributes th,
.team-member.design-two .team-socials .fa,
.portfolio-block strong,
.keydesign-cart .nc-icon-outline-cart,
.portfolio-meta.share-meta .fa,
.woocommerce .price_slider_wrapper .price_slider_amount,
.subscribe input[type="submit"],
.port-prev.tt_button,
.port-next.tt_button,
.es-accordion .es-speaker-container .es-speaker-name,
.pricing-title,
.woocommerce input.button,
.woocommerce button.button,
.wpcf7-select,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,
.woocommerce-cart  #single-page table.cart .product-name a,
#kd-slider .tt_button,
.wpb-js-composer .vc_tta-container .vc_tta-color-white.vc_tta-style-modern .vc_tta-tab>a,
.pricing .pricing-time,
.app-gallery .ag-section-desc h4,
.single-post .wpb_text_column strong,
.page-404 .section-subheading,
.testimonials .tt-content .content {
	color: #1f1f1f;
	color: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;
}

.cb-container:hover,
#header,
.kd-photobox .phb-content .phb-btncontainer a:hover {
	background: #333;
	background: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;
}


.testimonials.slider .owl-controls .owl-page:hover span
 {
	border-color: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;
}



.wpcf7 .wpcf7-text::-webkit-input-placeholder {color: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;}
.wpcf7 .wpcf7-text::-moz-placeholder {color: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;}
.wpcf7 .wpcf7-text:-ms-input-placeholder {color: <?php echo esc_attr($redux_ThemeTek['tek-heading-typo']['color']); ?>;}


#commentform #submit:hover,
.navbar-default,
.subscribe-form header .wpcf7-submit:hover,
#headerbackground,
.contact .wpcf7-submit:hover,
footer,
#posts-content .post input[type="submit"]:hover,
.navbar-default.navbar-shrink,
.btn-xl:hover,
.btn-xl:focus,
.btn-xl:active,
.btn-xl.active {
	background: #fff;
	background: <?php echo esc_attr($redux_ThemeTek['tek-secondary-color']); ?>;
}

@media (min-width: 960px) {
.home.page-template-default .navbar.navbar-default.navbar-shrink,
.single-portfolio .navbar.navbar-default.navbar-shrink,
.single-portfolio .navbar.navbar-default.navbar-shrink,
.single-post .navbar.navbar-default.navbar-shrink,
.woocommerce-page .navbar.navbar-default.navbar-shrink,
.page-template-default .navbar.navbar-default.navbar-shrink,
.page-template-portfolio-php .navbar.navbar-default.navbar-shrink,
.attachment .navbar.navbar-default.navbar-shrink {
	background: #fff;
	background: <?php echo esc_attr($redux_ThemeTek['tek-secondary-color']); ?>;
}
}

.subscribe-form header .wpcf7-response-output,
.subscribe .wpcf7-not-valid-tip,
.secondary-button:hover {
	color: #fff;
	color:  <?php echo esc_attr($redux_ThemeTek['tek-secondary-color']); ?>;
}

.upper-footer {
	background: #fafafa;
	background:  <?php if (isset($redux_ThemeTek['tek-upper-footer-color'])) { echo esc_attr($redux_ThemeTek['tek-upper-footer-color']); } ?>;
}

.lower-footer {
	background: #fff;
	background:  <?php if (isset($redux_ThemeTek['tek-lower-footer-color'])) { echo esc_attr($redux_ThemeTek['tek-lower-footer-color']); } ?>;
}

.lower-footer, .upper-footer {
	color:  <?php if (isset($redux_ThemeTek['tek-footer-text-color'])) { echo esc_attr($redux_ThemeTek['tek-footer-text-color']); } ?>;
}

.upper-footer .widget-title, .upper-footer .modal-menu-item {
	color:  <?php if (isset($redux_ThemeTek['tek-footer-heading-color'])) { echo esc_attr($redux_ThemeTek['tek-footer-heading-color']); } ?>;
}

.keydesign-cart .keydesign-cart-dropdown,
.navbar.navbar-default .dropdown-menu,
.navbar.navbar-default {
	background: <?php if (isset($redux_ThemeTek['tek-header-menu-bg'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-bg']); } ?>!important;
}


#main-menu .navbar-nav .menu-item-has-children .dropdown-menu, .navbar-nav .menu-item-has-children .dropdown-menu,
.single-portfolio .navbar.navbar-default,
.single-post .navbar.navbar-default,
.blog .navbar.navbar-default,
.navbar.navbar-default.navbar-shrink .keydesign-cart .keydesign-cart-dropdown,
.navbar.navbar-default.navbar-shrink .dropdown-menu,
.navbar.navbar-default.navbar-shrink {
	background: <?php if (isset($redux_ThemeTek['tek-header-menu-bg-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-bg-sticky']); } ?>!important;
}


.keydesign-cart .keydesign-cart-dropdown,
.keydesign-cart .nc-icon-outline-cart,
.navbar.navbar-default a {
	color: <?php if (isset($redux_ThemeTek['tek-header-menu-color'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color']); } ?>!important;
}


.navbar-default .navbar-toggle .icon-bar {
	background: <?php if (isset($redux_ThemeTek['tek-header-menu-color-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color-sticky']); } ?>!important;
}


#main-menu .navbar-nav .menu-item-has-children .mobile-dropdown,
#main-menu .navbar-nav .menu-item-has-children .dropdown-menu a, .navbar-nav .menu-item-has-children .dropdown-menu a,
.navbar.navbar-default.navbar-shrink .keydesign-cart .keydesign-cart-dropdown,
.navbar.navbar-default.navbar-shrink .keydesign-cart .nc-icon-outline-cart,
.navbar.navbar-default.navbar-shrink a,
.single-post .navbar.navbar-default a,
.blog .navbar.navbar-default a,
.single-portfolio .navbar.navbar-default a
{
	color: <?php if (isset($redux_ThemeTek['tek-header-menu-color-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color-sticky']); } ?>!important;
}

#main-menu .navbar-nav .menu-item-has-children .dropdown-menu a:hover, .navbar-nav .menu-item-has-children .dropdown-menu a:hover,
.navbar.navbar-default a:hover {
	color: <?php if (isset($redux_ThemeTek['tek-header-menu-color-sticky-hover'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color-sticky-hover']); } ?>!important;
}


#logo .logo {
	color: <?php if (isset($redux_ThemeTek['tek-main-logo-color'])) { echo esc_attr($redux_ThemeTek['tek-main-logo-color']); } ?>!important;
}

.blog #logo .logo,
.single-post #logo .logo,
.single-portfolio #logo .logo,
.navbar-shrink #logo .logo {
	color: <?php if (isset($redux_ThemeTek['tek-secondary-logo-color'])) { echo esc_attr($redux_ThemeTek['tek-secondary-logo-color']); } ?>!important;
}





<?php if ($redux_ThemeTek['tek-heading-typekit-selector']) { ?>
.container h1, .container h2, .container h3, .pricing .col-lg-3, .chart, .pb_counter_number, .pc_percent_container {
	font-family: "<?php echo esc_attr($redux_ThemeTek['tek-heading-typekit-selector']) ?>"!important;
}
<?php } ?>

<?php if ($redux_ThemeTek['tek-body-typekit-selector']) { ?>
body, .box {
	font-family: "<?php echo esc_attr($redux_ThemeTek['tek-body-typekit-selector']) ?>"!important;
}
<?php } ?>

@media (max-width: 960px) {

#logo .logo {
	color: <?php if (isset($redux_ThemeTek['tek-header-menu-color-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color-sticky']); } ?>!important;
}
.navbar.navbar-default {
background: <?php if (isset($redux_ThemeTek['tek-header-menu-bg-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-bg-sticky']); } ?>!important;
}

.navbar.navbar-default a,
.modal-menu-item,
 .navbar-nav .menu-item a {
	color: <?php if (isset($redux_ThemeTek['tek-header-menu-color-sticky'])) { echo esc_attr($redux_ThemeTek['tek-header-menu-color-sticky']); } ?>!important;
}



}
