<?php $redux_ThemeTek = get_option( 'redux_ThemeTek' ); ?>







<!--<div class="section-costs">-->
<!--    <ul class="cost-items">-->
<!--        <li class="cost-item">-->
<!--            <div class="wrap-item cost-item-3">-->
<!--                <a href="#">-->
<!--                    <div class="wrap-title">-->
<!--                        <div class="wrap-img">-->
<!--                            <img class="img-item" src="http://landing-lametail/wp-content/themes/intact-child/images/item-cost-3.png" alt="">-->
<!--                        </div>-->
<!--                        <h3 class="title">BASIC THAI</h3>-->
<!--                        <span class="after-title"></span>-->
<!--                    </div>-->
<!--                    <p class="description">4 ليالي بباتايا + 4 ليالي بجزيرة بوكيت + 3 ليالي ببانكوك + 2 تذاكر طيران داخلي + اوتيلات 4 نجوم مركزية + وجبة فطور! كرت طيران لتايلند</p>-->
<!--                    <p class="costs"><span class="costs-span">4,444</span> شيقل</p>-->
<!--                </a>-->
<!--            </div>-->
<!--        </li>-->
<!--        <li class="cost-item">-->
<!--            <div class="wrap-item cost-item-2">-->
<!--                <a href="#">-->
<!--                    <div class="wrap-title">-->
<!--                        <div class="wrap-img">-->
<!--                            <img class="img-item" src="http://landing-lametail/wp-content/themes/intact-child/images/item-cost-2.png" alt="">-->
<!--                        </div>-->
<!--                        <h3 class="title">THAI PLUS</h3>-->
<!--                        <span class="after-title"></span>-->
<!--                    </div>-->
<!--                    <p class="description">كرت طيارة لتايلند + 11 ليلة بفنادق 4 نجوم مركزية + وجبات افطار + طيران داخلي + مواصلات من بوكيت لكرابي</p>-->
<!--                    <p class="costs"><span class="costs-span">4,999</span> شيقل</p>-->
<!--                </a>-->
<!--            </div>-->
<!--        </li>-->
<!--        <li class="cost-item">-->
<!--            <div class="wrap-item cost-item-1">-->
<!--                <a href="#">-->
<!--                    <div class="wrap-title">-->
<!--                        <div class="wrap-img">-->
<!--                            <img class="img-item" src="http://landing-lametail/wp-content/themes/intact-child/images/item-cost-1.png" alt="">-->
<!--                        </div>-->
<!--                        <h3 class="title">THAI PREMIUM</h3>-->
<!--                        <span class="after-title">شهر العسل</span>-->
<!--                    </div>-->
<!--                    <p class="description">12 يوم و 11 ليلة من الخيال في افخم اوتيلات تايلند 5 نجوم مع الطيران الخارجي و2 طيران داخلي ومش بس هيك،</p>-->
<!--                    <p class="costs"><span class="costs-span">6,999</span> شيقل</p>-->
<!--                </a>-->
<!--            </div>-->
<!--        </li>-->
<!--    </ul>-->
<!--    <div class="wrap-button">-->
<!--        <a href="#"><img width="240" height="50" src="http://landing-lametail/wp-content/uploads/2018/01/sendbtna.png" class="vc_single_image-img attachment-full" alt=""></a>-->
<!--    </div>-->
<!--</div>-->
<!---->
<!--<br>-->




</div>
<footer id="footer" class="<?php if (isset($redux_ThemeTek['tek-footer-fixed'])) { if ($redux_ThemeTek['tek-footer-fixed'] == '1') { echo esc_html('fixed'); } else { echo esc_html('classic');} } ?>">
      <?php get_sidebar( 'footer' ); ?>
      <div class="lower-footer">
          <div class="container">
             <div class="pull-left">
               <span><?php echo isset($redux_ThemeTek['tek-footer-text']) ? $redux_ThemeTek['tek-footer-text'] : '&copy; 2017 Intact All rights reserved'; ?></span>
            </div>
            <div class="pull-right">
               <?php if ( has_nav_menu( 'keydesign-footer-menu' ) ) {
                     wp_nav_menu( array( 'theme_location' => 'keydesign-footer-menu', 'menu' => 'Footer Menu', 'depth' => 1, 'container' => false, 'menu_class' => 'nav navbar-footer', 'fallback_cb' => 'false' ) );
                  }
               ?>
            </div>
         </div>
      </div>
</footer>

<div style="display: none;">
<div id="lbp-inline-href-2" style="padding: 1px; background: #fff;">
<?php echo do_shortcode('[gravityform id="2" title="false" description="false" ajax="true"]'); ?>
</div>
</div>

      <?php if (!isset($redux_ThemeTek['tek-coming-soon-page'])) $redux_ThemeTek['tek-coming-soon-page'] = '';
      if (is_page($redux_ThemeTek['tek-coming-soon-page']) && $redux_ThemeTek['tek-coming-soon-page'] != '') { ?> </div> <?php } ?>
<?php if (isset($redux_ThemeTek['tek-backtotop']) && $redux_ThemeTek['tek-backtotop'] == "1") : ?>
      <div class="back-to-top">
         <i class="fa fa-angle-up"></i>
      </div>
<?php endif; ?>
<script>
    jQuery(function() {

        jQuery(document).ready(function(){
            jQuery(".button-mobile").on("click","a", function (event) {
                //отменяем стандартную обработку нажатия по ссылке
                event.preventDefault();

                //забираем идентификатор бока с атрибута href
                var id  = jQuery(this).attr('href'),

                    //узнаем высоту от начала страницы до блока на который ссылается якорь
                    top = jQuery(id).offset().top;

                //анимируем переход на расстояние - top за 1500 мс
                jQuery('body,html').animate({scrollTop: top}, 500);
            });
        });

    });
</script>
<?php wp_footer(); ?>

</body>
</html>
